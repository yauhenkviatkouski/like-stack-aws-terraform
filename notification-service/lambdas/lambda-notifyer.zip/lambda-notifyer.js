const AWS = require("aws-sdk");
const nodemailer = require("nodemailer");
const smtpTransport = require("nodemailer-smtp-transport");

const localstackMockParameters = process.env.LOCALSTACK_HOSTNAME
  ? {
      endpoint: `http://${process.env.LOCALSTACK_HOSTNAME}:4566`,
      region: "eu-west-1",
      accessKeyId: "test",
      secretAccessKey: "test",
    }
  : {};

const dynamo = new AWS.DynamoDB({
  apiVersion: "2012-08-10",
  ...localstackMockParameters,
});

exports.handler = async function (event) {
  console.log("\n\n\n\n\n-------------------------------------------");
  return await Promise.allSettled(
    event.Records.map(async (record) => {
      try {
        const snsMessage = JSON.parse(record.body);
        const { questionId } = snsMessage.MessageAttributes;
        const messageText = snsMessage.Message;
        const dbResponse = await dynamo
          .getItem({
            TableName: process.env.SUBSCRIBERS_DB_TABLE_NAME,
            Key: {
              questionId: { S: questionId },
            },
          })
          .promise();
        const questionSubscribers = dbResponse.Item.subscribers.SS;
        const transporter = nodemailer.createTransport(
          smtpTransport({
            service: "gmail",
            auth: {
              user: process.env.SES_ACCESS_KEY,
              pass: process.env.SES_SECRET_KEY,
            },
          })
        );
        return Promise.allSettled(
          questionSubscribers.map(async (subscriber) => {
            const mailOptions = {
              from: "lsapp.mail@gmail.com",
              to: "kvetkovski@gmail.com",
              subject: "Like-stack questions update",
              text: messageText,
            };

            return await transporter.sendMail(mailOptions);
          })
        );
      } catch (err) {
        console.log(
          "🚀 ~ file: lambda-subscriber.js ~ line 73 ~ event.Records.map ~ err",
          err
        );
        return err;
      }
    })
  );
};
